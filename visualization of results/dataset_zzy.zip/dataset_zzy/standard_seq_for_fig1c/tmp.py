from Bio import SeqIO
import pandas as pd

def main_PB1():
    outF = open("PB1.fas", "w")
    for record in SeqIO.parse("./PB1_ori.fasta", "fasta"):
        outF.write(">%s\n%s\n" % (record.id, record.seq[0:755]))
    outF.close()
    

def main_PB1F2():
    outF = open("PB1-F2.fas", "w")
    for record in SeqIO.parse("./PB1-F2_ori.fasta", "fasta"):
        outF.write(">%s\n%s\n" % (record.id, record.seq[0:87]))
    outF.close()


def main_NS_NS1_NS2():
    outF1 = open("NS1.fas", "w")
    outF2 = open("NS2.fas", "w")
    for record in SeqIO.parse("./NS.fasta", "fasta"):
        seqid, sequ = record.id, record.seq
        if len(seqid.split("NS1"))>1:
            outF1.write(">%s\n%s\n" % (seqid, sequ[0:217]))
        elif len(seqid.split("NS2"))>1:
            outF2.write(">%s\n%s\n" % (seqid, sequ))
    outF1.close()
    outF2.close()

if __name__ == "__main__":
    main_NS_NS1_NS2()

