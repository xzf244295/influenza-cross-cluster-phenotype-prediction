"""
Fig1C amino-acid physicochemical property analysis

核心逻辑：
1. 已知功能性替换：
   original AA     = 替换前氨基酸
   substitution AA = 替换后氨基酸

2. 如果 substitution AA == original AA：
   - 整个位点直接删除
   - substitution 不进入分析
   - 该位点对应的 control 也不构建、不进入分析

3. 每个蛋白从标准 FASTA 中随机抽取最多1000条序列：
   - 不放回
   - 少于1000条则全部使用

4. 每个功能位点：
   - 提取随机序列对应位置的AA
   - 去除与 original AA 相同的AA
   - 不使用 set()，保留真实出现频率

5. 计算三种性质：
   polarity
   hydrophilicity
   charge

6. 主分析采用绝对变化：
   Substitution = |property(substitution) - property(original)|
   Control      = mean(|property(control AA) - property(original)|)

7. 每个位点作为一个统计单位：
   paired Wilcoxon signed-rank test

8. polarity / hydrophilicity / charge 三次检验使用 BH-FDR 校正。

9. 绘图：
   x = Substitution / Control
   y = absolute property change
   箱线图 + 散点
   不连接成对数据点
   图上显示显著性
"""

import os
import re
import random
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from Bio import SeqIO
from scipy.stats import wilcoxon
from statsmodels.stats.multitest import multipletests


# ============================================================
# 全局参数
# ============================================================

RANDOM_SEED = 42
N_SEQUENCES = 1000

random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

VALID_AA = set("ACDEFGHIKLMNPQRSTVWY")


# ============================================================
# 氨基酸理化性质
# ============================================================

# Grantham polarity
POLARITY = {
    "A": 8.1, "R": 10.5, "N": 11.6, "D": 13.0, "C": 5.5,
    "Q": 10.5, "E": 12.3, "G": 9.0, "H": 10.4, "I": 5.2,
    "L": 4.9, "K": 11.3, "M": 5.7, "F": 5.2, "P": 8.0,
    "S": 9.2, "T": 8.6, "W": 5.4, "Y": 6.2, "V": 5.9
}

# Hopp-Woods hydrophilicity
HYDROPHILICITY = {
    "A": -0.5, "R": 3.0, "N": 0.2, "D": 3.0, "C": -1.0,
    "Q": 0.2, "E": 3.0, "G": 0.0, "H": -0.5, "I": -1.8,
    "L": -1.8, "K": 3.0, "M": -1.3, "F": -2.5, "P": 0.0,
    "S": 0.3, "T": -0.4, "W": -3.4, "Y": -2.3, "V": -1.5
}

# Simplified physiological charge
CHARGE = {
    "A": 0.0, "R": 1.0, "N": 0.0, "D": -1.0, "C": 0.0,
    "Q": 0.0, "E": -1.0, "G": 0.0, "H": 0.1, "I": 0.0,
    "L": 0.0, "K": 1.0, "M": 0.0, "F": 0.0, "P": 0.0,
    "S": 0.0, "T": 0.0, "W": 0.0, "Y": 0.0, "V": 0.0
}

AA_PROPERTIES = {"polarity": POLARITY, "hydrophilicity": HYDROPHILICITY, "charge": CHARGE}


# ============================================================
# 基础函数
# ============================================================

def clean_aa(aa):
    if pd.isna(aa): return None
    aa = str(aa).strip().upper()
    return aa if len(aa) == 1 and aa in VALID_AA else None


def calculate_property_diff(original_aa, target_aa, property_name):
    original_aa, target_aa = clean_aa(original_aa), clean_aa(target_aa)
    if original_aa is None or target_aa is None: return np.nan
    return AA_PROPERTIES[property_name][target_aa] - AA_PROPERTIES[property_name][original_aa]


# ============================================================
# Human adaptation预处理
# ============================================================

def fig1c_preprocess_host_adaptation():

    input_file = "../dataset_xzf/dt_for_fig1/human_adaptations_marker.csv"
    output_file = "../dataset_zzy/fig1c_aasite_parsed.csv"

    dt = pd.read_csv(input_file, encoding="gbk")
    dt["Avian residues"] = dt["Avian residues"].fillna("NoRes")
    dt = dt[dt["Avian residues"] != "NoRes"].reset_index(drop=True)
    dt = dt[dt["Protein Type"] != "NEP"].reset_index(drop=True)

    def parse_residues_with_protein(residue_str, default_protein):

        residue_str = str(residue_str).strip()
        results = []

        if re.match(r"^[\d&]+$", residue_str): return results

        combo_match = re.match(r"^([\d&]+)([A-Z]+)$", residue_str)
        if combo_match:
            sites, residues = combo_match.group(1).split("&"), list(combo_match.group(2))
            for i in range(min(len(sites), len(residues))): results.append((default_protein, sites[i], residues[i]))
            return results

        if "&" in residue_str:
            for part in residue_str.split("&"):
                part = part.strip()

                complex_match = re.match(r"^([A-Za-z0-9]+)-[A-Za-z0-9]+-(\d+)([A-Z]+)$", part)
                if complex_match:
                    results.append((complex_match.group(1), complex_match.group(2), complex_match.group(3)))
                    continue

                protein_match = re.match(r"^([A-Za-z0-9]+)-(\d+)([A-Z]+)$", part)
                if protein_match:
                    results.append((protein_match.group(1), protein_match.group(2), protein_match.group(3)))
                    continue

                std_match = re.match(r"^(\d+)([A-Z]+)$", part)
                if std_match:
                    results.append((default_protein, std_match.group(1), std_match.group(2)))
                    continue

                bracket_match = re.match(r"^(\d+)([A-Z]+)\([^)]+\)$", part)
                if bracket_match:
                    results.append((default_protein, bracket_match.group(1), bracket_match.group(2)))
                    continue

                if re.match(r"^\d+$", part): continue
                print("Warning: cannot parse:", part)

            return results

        complex_match = re.match(r"^([A-Za-z0-9]+)-[A-Za-z0-9]+-(\d+)([A-Z]+)$", residue_str)
        if complex_match:
            results.append((complex_match.group(1), complex_match.group(2), complex_match.group(3)))
            return results

        protein_match = re.match(r"^([A-Za-z0-9]+)-(\d+)([A-Z]+)$", residue_str)
        if protein_match:
            results.append((protein_match.group(1), protein_match.group(2), protein_match.group(3)))
            return results

        bracket_match = re.match(r"^(\d+)\[([A-Z]+)\]$", residue_str)
        if bracket_match:
            for residue in bracket_match.group(2): results.append((default_protein, bracket_match.group(1), residue))
            return results

        std_match = re.match(r"^(\d+)([A-Z]+)$", residue_str)
        if std_match:
            results.append((default_protein, std_match.group(1), std_match.group(2)))
            return results

        special_match = re.match(r"^(\d+)([A-Z]+)\s*\([^)]+\)$", residue_str)
        if special_match:
            results.append((default_protein, special_match.group(1), special_match.group(2)))
            return results

        print("Warning: cannot parse residue:", residue_str)
        return results

    new_rows = []

    for _, row in dt.iterrows():

        default_protein = row["Protein Type"]
        human_parsed = parse_residues_with_protein(str(row["Human residues"]).strip(), default_protein)
        avian_parsed = parse_residues_with_protein(str(row["Avian residues"]).strip(), default_protein)

        if not human_parsed or not avian_parsed: continue

        human_dict, avian_dict = {}, {}

        for prot, site, residue in human_parsed: human_dict.setdefault((str(prot), int(site)), []).append(residue)
        for prot, site, residue in avian_parsed: avian_dict.setdefault((str(prot), int(site)), []).append(residue)

        for prot, site in sorted(set(human_dict) & set(avian_dict), key=lambda x: (x[0], x[1])):
            for h_residue in human_dict[(prot, site)]:
                for a_residue in avian_dict[(prot, site)]:
                    h_aa, a_aa = clean_aa(h_residue), clean_aa(a_residue)
                    if h_aa is None or a_aa is None: continue
                    new_rows.append({"Protein Type": prot, "Human Site": site, "Human Residue": h_aa, "Avian Site": site, "Avian Residue": a_aa})

    result_df = pd.DataFrame(new_rows).drop_duplicates(ignore_index=True)
    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    result_df.to_csv(output_file, index=False)

    print("\nHuman adaptation preprocessing:")
    print("Number of markers:", len(result_df))
    print("Saved to:", output_file)


# ============================================================
# Receptor preference预处理
# ============================================================

def fig1c_preprocess_recep_prefer():

    input_file = "../dataset_xzf/dt_for_fig1/receptor_binding_marker_with_ori.csv"
    output_file = "../dataset_zzy/dt_for_fig1c_recep_prefer_parsed.csv"

    dt = pd.read_csv(input_file)
    new_rows = []

    for idx, row in dt.iterrows():

        protein = row["Protein Type"]

        for part in str(row["ori_source"]).strip().split("&"):

            part = part.strip()
            match = re.match(r"^([A-Z])(\d+)([A-Z])$", part)

            if not match:
                print(f"Skip row {idx}: {part}")
                continue

            original_aa, site, target_aa = clean_aa(match.group(1)), int(match.group(2)), clean_aa(match.group(3))
            if original_aa is None or target_aa is None: continue

            new_rows.append({"Protein Type": protein, "Human Site": site, "Human Residue": target_aa, "Avian Site": site, "Avian Residue": original_aa})

    result_df = pd.DataFrame(new_rows).drop_duplicates(ignore_index=True)
    result_df.to_csv(output_file, index=False)

    print("\nReceptor preference preprocessing:")
    print("Number of markers:", len(result_df))
    print("Saved to:", output_file)


# ============================================================
# Virulence预处理
# ============================================================

def fig1c_preprocess_virulence():

    input_file = "../dataset_xzf/dt_for_fig1/mammalian_virulences_marker_with_ori.csv"
    output_file = "../dataset_zzy/dt_for_fig1c_virulence_parsed.csv"

    dt = pd.read_csv(input_file)
    dt = dt[dt["Protein Type"] != "combination"].reset_index(drop=True)
    new_rows = []

    for idx, row in dt.iterrows():

        protein = row["Protein Type"]

        for part in str(row["ori_source"]).strip().split("&"):

            part = part.strip()
            match = re.match(r"^([A-Z])(\d+)([A-Z])$", part)

            if not match:
                print(f"Skip row {idx}: {part}")
                continue

            original_aa, site, target_aa = clean_aa(match.group(1)), int(match.group(2)), clean_aa(match.group(3))
            if original_aa is None or target_aa is None: continue

            new_rows.append({"Protein Type": protein, "Human Site": site, "Human Residue": target_aa, "Avian Site": site, "Avian Residue": original_aa})

    result_df = pd.DataFrame(new_rows).drop_duplicates(ignore_index=True)
    result_df.to_csv(output_file, index=False)

    print("\nVirulence preprocessing:")
    print("Number of markers:", len(result_df))
    print("Saved to:", output_file)


# ============================================================
# 随机抽取FASTA序列
# ============================================================

def random_sample_fasta_sequences(fasta_dir, n_sequences=1000, seed=42):

    rng = random.Random(seed)
    fasta_files = sorted([os.path.join(fasta_dir, f) for f in os.listdir(fasta_dir) if f.endswith((".fas", ".fasta", ".fa"))])

    if len(fasta_files) == 0: raise FileNotFoundError(f"No FASTA files found in: {fasta_dir}")

    selected_seq = {}

    for fasta_file in fasta_files:

        seq_list = [str(record.seq).upper() for record in SeqIO.parse(fasta_file, "fasta")]
        protein_name = os.path.splitext(os.path.basename(fasta_file))[0]
        total_n = len(seq_list)

        if total_n == 0:
            warnings.warn(f"{protein_name}: FASTA is empty")
            selected_seq[protein_name] = []
            continue

        if total_n >= n_sequences:
            sampled = rng.sample(seq_list, n_sequences)
        else:
            sampled = list(seq_list)
            warnings.warn(f"{protein_name}: only {total_n} sequences; use all sequences instead of {n_sequences}")

        selected_seq[protein_name] = sampled
        print(f"{protein_name}: total={total_n}, sampled={len(sampled)}")

    return selected_seq


# ============================================================
# 核心分析
# ============================================================

def analyse_amino_acid_markers(marker_file, fasta_dir, output_prefix, n_sequences=1000, seed=42, exclude_proteins=None):

    if exclude_proteins is None: exclude_proteins = []

    # ========================================================
    # 读取marker
    # ========================================================

    dt = pd.read_csv(marker_file)

    required_columns = ["Protein Type", "Human Site", "Human Residue", "Avian Residue"]
    missing_cols = [c for c in required_columns if c not in dt.columns]

    if missing_cols: raise ValueError(f"Missing columns: {missing_cols}")

    dt = dt.copy()

    dt["Human Site"] = pd.to_numeric(dt["Human Site"], errors="coerce")
    dt = dt[dt["Human Site"].notna()].copy()
    dt["Human Site"] = dt["Human Site"].astype(int)

    dt["Human Residue"] = dt["Human Residue"].apply(clean_aa)
    dt["Avian Residue"] = dt["Avian Residue"].apply(clean_aa)

    dt = dt[dt["Human Residue"].notna() & dt["Avian Residue"].notna()].copy()

    # ========================================================
    # 非常重要：
    #
    # 如果替换前 == 替换后
    # 整个位点直接删除
    #
    # 后面不会为该位点构建Control
    # ========================================================

    n_before_same_filter = len(dt)

    dt = dt[dt["Human Residue"] != dt["Avian Residue"]].copy()

    n_removed_same = n_before_same_filter - len(dt)

    print("\nSame-AA marker filtering:")
    print("Markers before filtering:", n_before_same_filter)
    print("Markers removed because original AA == substitution AA:", n_removed_same)
    print("Markers remaining:", len(dt))

    # ========================================================
    # 排除指定蛋白
    # ========================================================

    if exclude_proteins: dt = dt[~dt["Protein Type"].isin(exclude_proteins)].copy()

    dt.drop_duplicates(inplace=True)
    dt.reset_index(drop=True, inplace=True)

    print("Number of markers before sequence filtering:", len(dt))

    # ========================================================
    # 随机抽取FASTA
    # ========================================================

    selected_sequences = random_sample_fasta_sequences(fasta_dir=fasta_dir, n_sequences=n_sequences, seed=seed)

    summary_rows, long_rows = [], []

    # ========================================================
    # 遍历所有marker
    # ========================================================

    for marker_id, row in dt.iterrows():

        protein = str(row["Protein Type"])
        site = int(row["Human Site"])
        original_aa = row["Avian Residue"]
        substitution_aa = row["Human Residue"]

        # 双保险
        if original_aa == substitution_aa:
            print(f"Skip identical substitution: {protein} {site} {original_aa}->{substitution_aa}")
            continue

        if protein not in selected_sequences:
            print(f"Warning: no FASTA for protein {protein}; skip")
            continue

        sequences = selected_sequences[protein]

        # ====================================================
        # 获取随机序列该位点AA
        # ====================================================

        sampled_residues = []
        n_out_of_range, n_invalid = 0, 0

        for seq in sequences:

            if site > len(seq):
                n_out_of_range += 1
                continue

            aa = clean_aa(seq[site - 1])

            if aa is None:
                n_invalid += 1
                continue

            sampled_residues.append(aa)

        # ====================================================
        # Control：
        #
        # 删除与original AA一样的AA
        # 保留真实出现次数，不使用set()
        # ====================================================

        different_residues = [aa for aa in sampled_residues if aa != original_aa]

        if len(different_residues) == 0:
            print(f"Skip: {protein} {site} {original_aa}->{substitution_aa}; no different control residues")
            continue

        residue_counts = pd.Series(different_residues).value_counts().to_dict()
        residue_frequency_string = ";".join([f"{aa}:{count}" for aa, count in sorted(residue_counts.items())])

        # ====================================================
        # Site-level基础信息
        # ====================================================

        summary = {
            "Marker ID": marker_id,
            "Protein Type": protein,
            "Site": site,
            "Original Residue": original_aa,
            "Substitution Residue": substitution_aa,
            "N sampled sequences": len(sequences),
            "N valid site residues": len(sampled_residues),
            "N identical control removed": len(sampled_residues) - len(different_residues),
            "N different residues": len(different_residues),
            "Different residue frequency": residue_frequency_string,
            "N site out of range": n_out_of_range,
            "N invalid AA": n_invalid
        }

        # ====================================================
        # 三种理化性质
        # ====================================================

        for prop in ["polarity", "hydrophilicity", "charge"]:

            # ------------------------------------------------
            # Substitution
            # ------------------------------------------------

            substitution_diff = calculate_property_diff(original_aa, substitution_aa, prop)
            substitution_abs = abs(substitution_diff)

            # ------------------------------------------------
            # Control
            # ------------------------------------------------

            control_diffs = np.asarray([calculate_property_diff(original_aa, aa, prop) for aa in different_residues], dtype=float)
            control_diffs = control_diffs[~np.isnan(control_diffs)]

            control_abs = np.abs(control_diffs)

            # ------------------------------------------------
            # Site summary
            # ------------------------------------------------

            summary[f"Substitution_{prop}_diff"] = substitution_diff
            summary[f"Substitution_{prop}_abs"] = substitution_abs

            summary[f"Control_{prop}_mean"] = np.mean(control_diffs) if len(control_diffs) else np.nan
            summary[f"Control_{prop}_median"] = np.median(control_diffs) if len(control_diffs) else np.nan
            summary[f"Control_{prop}_std"] = np.std(control_diffs, ddof=1) if len(control_diffs) > 1 else np.nan

            summary[f"Control_{prop}_abs_mean"] = np.mean(control_abs) if len(control_abs) else np.nan
            summary[f"Control_{prop}_abs_median"] = np.median(control_abs) if len(control_abs) else np.nan

            # ------------------------------------------------
            # Long-format：Substitution
            # ------------------------------------------------

            long_rows.append({
                "Marker ID": marker_id,
                "Protein Type": protein,
                "Site": site,
                "Original Residue": original_aa,
                "Target Residue": substitution_aa,
                "Group": "Substitution",
                "Property": prop,
                "Difference": substitution_diff,
                "Abs Difference": substitution_abs
            })

            # ------------------------------------------------
            # Long-format：Control
            # ------------------------------------------------

            for aa in different_residues:

                diff = calculate_property_diff(original_aa, aa, prop)

                if np.isnan(diff): continue

                long_rows.append({
                    "Marker ID": marker_id,
                    "Protein Type": protein,
                    "Site": site,
                    "Original Residue": original_aa,
                    "Target Residue": aa,
                    "Group": "Control",
                    "Property": prop,
                    "Difference": diff,
                    "Abs Difference": abs(diff)
                })

        summary_rows.append(summary)

    # ========================================================
    # 保存
    # ========================================================

    summary_df = pd.DataFrame(summary_rows)
    long_df = pd.DataFrame(long_rows)

    summary_file = f"{output_prefix}_site_summary.csv"
    long_file = f"{output_prefix}_long.csv"

    summary_df.to_csv(summary_file, index=False)
    long_df.to_csv(long_file, index=False)

    print("\n" + "=" * 70)
    print("Analysis completed")
    print("Markers retained:", len(summary_df))
    print("Site summary:", summary_file)
    print("Long-format data:", long_file)
    print("=" * 70 + "\n")

    return summary_df, long_df


# ============================================================
# 显著性符号
# ============================================================

def significance_label(fdr):
    if pd.isna(fdr): return "NA"
    if fdr < 0.0001: return "****"
    if fdr < 0.001: return "***"
    if fdr < 0.01: return "**"
    if fdr < 0.05: return "*"
    return "ns"


# ============================================================
# Boxplot + paired Wilcoxon
# ============================================================

def plot_property_comparison(summary_df, output_prefix, use_absolute=True):

    """
    主分析：

    每个位点：
        Substitution_i
        Control_i

    absolute：
        Substitution_i = |Δproperty|
        Control_i = mean(|Δproperty_background|)

    signed：
        Substitution_i = Δproperty
        Control_i = mean(Δproperty_background)

    统计：
        paired Wilcoxon signed-rank test

    注意：
        绘图不连接Substitution和Control散点。
        但统计仍然采用paired Wilcoxon。
    """

    properties = ["polarity", "hydrophilicity", "charge"]

    labels_absolute = {
        "polarity": "Absolute polarity change",
        "hydrophilicity": "Absolute hydrophilicity change",
        "charge": "Absolute charge change"
    }

    labels_signed = {
        "polarity": "Polarity change",
        "hydrophilicity": "Hydrophilicity change",
        "charge": "Charge change"
    }

    # ========================================================
    # 1. Wilcoxon
    # ========================================================

    statistics_results = []

    for prop in properties:

        if use_absolute:
            exp_col, ctrl_col = f"Substitution_{prop}_abs", f"Control_{prop}_abs_mean"
        else:
            exp_col, ctrl_col = f"Substitution_{prop}_diff", f"Control_{prop}_mean"

        tmp = summary_df[[exp_col, ctrl_col]].dropna().copy()
        exp_values, ctrl_values = tmp[exp_col].to_numpy(), tmp[ctrl_col].to_numpy()

        if len(tmp) < 2:
            statistic, p_value = np.nan, np.nan
        elif np.allclose(exp_values - ctrl_values, 0):
            statistic, p_value = 0.0, 1.0
        else:
            try:
                statistic, p_value = wilcoxon(exp_values, ctrl_values, alternative="two-sided", zero_method="wilcox")
            except ValueError:
                statistic, p_value = np.nan, np.nan

        statistics_results.append({
            "Property": prop,
            "N": len(tmp),
            "Substitution_mean": np.mean(exp_values) if len(exp_values) else np.nan,
            "Control_mean": np.mean(ctrl_values) if len(ctrl_values) else np.nan,
            "Substitution_median": np.median(exp_values) if len(exp_values) else np.nan,
            "Control_median": np.median(ctrl_values) if len(ctrl_values) else np.nan,
            "Median_paired_difference": np.median(exp_values - ctrl_values) if len(exp_values) else np.nan,
            "Wilcoxon_statistic": statistic,
            "P_value": p_value
        })

    stats_df = pd.DataFrame(statistics_results)

    # ========================================================
    # 2. BH-FDR
    # ========================================================

    stats_df["FDR"] = np.nan
    valid_mask = stats_df["P_value"].notna()

    if valid_mask.sum() > 0:
        stats_df.loc[valid_mask, "FDR"] = multipletests(stats_df.loc[valid_mask, "P_value"], method="fdr_bh")[1]

    stats_df["Significance"] = stats_df["FDR"].apply(significance_label)

    suffix = "absolute" if use_absolute else "signed"
    stats_file = f"{output_prefix}_property_statistics_{suffix}.csv"

    stats_df.to_csv(stats_file, index=False)

    print("\n" + "=" * 100)
    print(f"Property statistics: {output_prefix}")
    print("=" * 100)

    print(stats_df.round({
        "Substitution_mean": 4,
        "Control_mean": 4,
        "Substitution_median": 4,
        "Control_median": 4,
        "Median_paired_difference": 4,
        "Wilcoxon_statistic": 4,
        "P_value": 6,
        "FDR": 6
    }).to_string(index=False))

    print("\nStatistics saved:", stats_file)

    # ========================================================
    # 3. 三张箱线图
    # ========================================================

    for prop in properties:

        if use_absolute:
            exp_col, ctrl_col = f"Substitution_{prop}_abs", f"Control_{prop}_abs_mean"
            ylabel = labels_absolute[prop]
        else:
            exp_col, ctrl_col = f"Substitution_{prop}_diff", f"Control_{prop}_mean"
            ylabel = labels_signed[prop]

        tmp = summary_df[[exp_col, ctrl_col]].dropna().copy()

        if len(tmp) == 0:
            print(f"No valid data for {prop}")
            continue

        exp_values, ctrl_values = tmp[exp_col].to_numpy(), tmp[ctrl_col].to_numpy()

        stat_row = stats_df[stats_df["Property"] == prop].iloc[0]
        p_value, fdr, sig = stat_row["P_value"], stat_row["FDR"], stat_row["Significance"]

        # ====================================================
        # Figure
        # ====================================================

        fig, ax = plt.subplots(figsize=(3, 3))

        # ----------------------------------------------------
        # 箱线图
        # ----------------------------------------------------

        ax.boxplot(
            [exp_values, ctrl_values],
            positions=[1, 2],
            widths=0.52,
            showfliers=False,
            patch_artist=True,
            boxprops={"facecolor": "white", "edgecolor": "black", "linewidth": 1.2},
            medianprops={"color": "black", "linewidth": 1.5},
            whiskerprops={"color": "black", "linewidth": 1.0},
            capprops={"color": "black", "linewidth": 1.0}
        )

        # ----------------------------------------------------
        # 散点
        #
        # 注意：
        # 这里不添加Substitution-Control连接线
        # ----------------------------------------------------

        rng = np.random.default_rng(RANDOM_SEED)

        jitter_sub = rng.normal(1, 0.045, len(tmp))
        jitter_ctrl = rng.normal(2, 0.045, len(tmp))

        ax.scatter(jitter_sub, exp_values, s=20, alpha=0.60, zorder=3)
        ax.scatter(jitter_ctrl, ctrl_values, s=20, alpha=0.60, zorder=3)

        # ====================================================
        # 显著性横线
        # ====================================================

        all_values = np.concatenate([exp_values, ctrl_values])

        data_min = np.nanmin(all_values)
        data_max = np.nanmax(all_values)
        data_range = data_max - data_min

        if data_range == 0: data_range = max(abs(data_max), 1.0)

        line_y = data_max + 0.10 * data_range
        bracket_height = 0.035 * data_range
        text_y = line_y + bracket_height + 0.015 * data_range

        ax.plot(
            [1, 1, 2, 2],
            [line_y, line_y + bracket_height, line_y + bracket_height, line_y],
            color="black",
            linewidth=1.0
        )

        ax.text(1.5, text_y, sig, ha="center", va="bottom", fontsize=12)

        # ====================================================
        # Y轴范围
        # ====================================================

        upper_lim = text_y + 0.10 * data_range

        if use_absolute:
            lower_lim = 0
        else:
            lower_lim = data_min - 0.10 * data_range

        ax.set_ylim(lower_lim, upper_lim)

        if not use_absolute: ax.axhline(0, color="grey", linestyle="--", linewidth=0.8)

        # ====================================================
        # 坐标轴
        # ====================================================

        ax.set_xticks([1, 2])
        ax.set_xticklabels(["Substitution", "Control"], fontsize=10)
        ax.set_ylabel(ylabel, fontsize=12)
        ax.set_xlabel("")
        ax.tick_params(axis="y", labelsize=10)

        #ax.spines["top"].set_visible(False)
        #ax.spines["right"].set_visible(False)
        ax.spines["top"].set_linewidth(1.2)
        ax.spines["bottom"].set_linewidth(1.2)
        ax.spines["left"].set_linewidth(1.2)
        ax.spines["right"].set_linewidth(1.2)

        # ====================================================
        # 显示具体FDR
        # ====================================================

        #if not pd.isna(fdr):
        #    ax.text(0.98, 0.98, f"FDR = {fdr:.3g}", transform=ax.transAxes, ha="right", va="top", fontsize=8)

        # ====================================================
        # 保存
        # ====================================================

        fig.tight_layout()

        pdf_file = f"{output_prefix}_{prop}_{suffix}.pdf"
        fig.savefig(pdf_file, dpi=300, bbox_inches="tight")

        plt.close(fig)

        print(f"\nPlot saved: {pdf_file}")
        print(f"N = {len(tmp)}")
        print(f"Wilcoxon P = {p_value:.6g}")
        print(f"FDR = {fdr:.6g}")
        print(f"Significance = {sig}")

    return stats_df


# ============================================================
# Human adaptation
# ============================================================

def random_select_seq_human_adaptation():

    marker_file = "../dataset_zzy/fig1c_aasite_parsed.csv"
    fasta_dir = "../dataset_zzy/standard_seq_for_fig1c/"
    output_prefix = "../dataset_zzy/fig1c_human_adaptation"

    summary_df, long_df = analyse_amino_acid_markers(
        marker_file=marker_file,
        fasta_dir=fasta_dir,
        output_prefix=output_prefix,
        n_sequences=N_SEQUENCES,
        seed=RANDOM_SEED,
        exclude_proteins=["HA1", "HA2", "M"]
    )

    stats_df = plot_property_comparison(summary_df, output_prefix, use_absolute=True)

    return summary_df, long_df, stats_df


# ============================================================
# Receptor preference
# ============================================================

def random_select_seq_recep_prefer():

    marker_file = "../dataset_zzy/dt_for_fig1c_recep_prefer_parsed.csv"
    fasta_dir = "../dataset_zzy/standard_seq_for_fig1c_recep_prefer/"
    output_prefix = "../dataset_zzy/fig1c_receptor_preference"

    summary_df, long_df = analyse_amino_acid_markers(
        marker_file=marker_file,
        fasta_dir=fasta_dir,
        output_prefix=output_prefix,
        n_sequences=N_SEQUENCES,
        seed=RANDOM_SEED
    )

    stats_df = plot_property_comparison(summary_df, output_prefix, use_absolute=True)

    return summary_df, long_df, stats_df


# ============================================================
# Virulence
# ============================================================

def random_select_seq_virulence():

    marker_file = "../dataset_zzy/dt_for_fig1c_virulence_parsed.csv"
    fasta_dir = "../dataset_zzy/standard_seq_for_fig1c_virulence/"
    output_prefix = "../dataset_zzy/fig1c_virulence"

    summary_df, long_df = analyse_amino_acid_markers(
        marker_file=marker_file,
        fasta_dir=fasta_dir,
        output_prefix=output_prefix,
        n_sequences=N_SEQUENCES,
        seed=RANDOM_SEED,
        exclude_proteins=["H"]
    )

    stats_df = plot_property_comparison(summary_df, output_prefix, use_absolute=True)

    return summary_df, long_df, stats_df


# ============================================================
# Main
# ============================================================

if __name__ == "__main__":

    ## 第一次运行或原始marker数据发生改变时运行
    #fig1c_preprocess_host_adaptation()
    #fig1c_preprocess_recep_prefer()
    #fig1c_preprocess_virulence()

    # 随机背景 + 理化性质分析 + 统计 + 绘图
    random_select_seq_human_adaptation()
    random_select_seq_recep_prefer()
    random_select_seq_virulence()