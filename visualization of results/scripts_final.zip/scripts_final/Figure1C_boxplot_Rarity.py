"""
Combined Fig1C: position conservation / substitution rarity analysis

核心逻辑
================================================================

1. 三类marker：
   - Human adaptation
   - Receptor preference
   - Virulence

   预处理后全部合并，不再区分场景。

2. 删除：
   original AA == substitution AA
   的marker。

3. 对每种蛋白：
   - 从对应FASTA中最多随机抽1000条序列
   - 严格不放回
   - 少于1000条则全部使用

4. 为提高速度：
   - FASTA只读取一次
   - 序列转换成NumPy二维字符矩阵
   - 每个位点直接取矩阵的一列
   - 缓存site AA distribution

5. Position conservation：

       H = -sum(p_i * log2(p_i))

       Conservation = 1 - H / log2(20)

   越接近1，位点越保守。

6. Rarity：

       P(target AA | site)
       = (count + pseudocount)
         /
         (N + 20 × pseudocount)

       Rarity = -log10(P)

   越大，说明该AA在这个位置越罕见。

7. Substitution：
       已知marker的替换后AA rarity

8. Control：
       从相同位点背景序列中，
       去掉original AA，
       保留剩余AA真实出现频率，
       计算每一个AA的rarity，
       再求site-level mean。

9. 最终统计单位 = marker substitution。

       Substitution_i vs Control_i

   使用：
       paired Wilcoxon signed-rank test

10. 最终只画一个Combined箱线图：
       X = Substitution / Control
       Y = Rarity score

11. 只输出PDF，不输出PNG。
"""

import os
import re
import random
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from Bio import SeqIO
from scipy.stats import wilcoxon


# ============================================================
# 全局参数
# ============================================================

RANDOM_SEED = 42
N_SEQUENCES = 1000
PSEUDOCOUNT = 0.5
MIN_VALID_FRACTION = 0.80

VALID_AA = np.array(list("ACDEFGHIKLMNPQRSTVWY"))
VALID_AA_SET = set(VALID_AA)
N_AA = len(VALID_AA)

random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)


# ============================================================
# 路径
# ============================================================

HOST_ADAPTATION_RAW = "../dataset_xzf/dt_for_fig1/human_adaptations_marker.csv"
RECEPTOR_RAW = "../dataset_xzf/dt_for_fig1/receptor_binding_marker_with_ori.csv"
VIRULENCE_RAW = "../dataset_xzf/dt_for_fig1/mammalian_virulences_marker_with_ori.csv"

HOST_PARSED = "../dataset_zzy/fig1c_aasite_parsed.csv"
RECEPTOR_PARSED = "../dataset_zzy/dt_for_fig1c_recep_prefer_parsed.csv"
VIRULENCE_PARSED = "../dataset_zzy/dt_for_fig1c_virulence_parsed.csv"

FASTA_DIRS = [
    "../dataset_zzy/standard_seq_for_fig1c/",
    "../dataset_zzy/standard_seq_for_fig1c_recep_prefer/",
    "../dataset_zzy/standard_seq_for_fig1c_virulence/"
]

OUTPUT_PREFIX = "../dataset_zzy/fig1c_combined_conservation_rarity"
FIGURE_FILE = "../figures/fig1c_combined_substitution_rarity.pdf"


# ============================================================
# 基础函数
# ============================================================

def clean_aa(aa):
    if pd.isna(aa): return None
    aa = str(aa).strip().upper()
    return aa if len(aa) == 1 and aa in VALID_AA_SET else None


def significance_label(p):
    if pd.isna(p): return "NA"
    if p < 0.0001: return "****"
    if p < 0.001: return "***"
    if p < 0.01: return "**"
    if p < 0.05: return "*"
    return "ns"


# ============================================================
# Human adaptation预处理
# ============================================================

def fig1c_preprocess_host_adaptation():

    dt = pd.read_csv(HOST_ADAPTATION_RAW, encoding="gbk")
    dt["Avian residues"] = dt["Avian residues"].fillna("NoRes")
    dt = dt[(dt["Avian residues"] != "NoRes") & (dt["Protein Type"] != "NEP")].reset_index(drop=True)

    def parse_residues_with_protein(residue_str, default_protein):

        residue_str = str(residue_str).strip()
        results = []

        if re.match(r"^[\d&]+$", residue_str): return results

        combo_match = re.match(r"^([\d&]+)([A-Z]+)$", residue_str)

        if combo_match:
            sites, residues = combo_match.group(1).split("&"), list(combo_match.group(2))
            for i in range(min(len(sites), len(residues))): results.append((default_protein, sites[i], residues[i]))
            return results

        if "&" in residue_str:

            for part in residue_str.split("&"):

                part = part.strip()

                m = re.match(r"^([A-Za-z0-9]+)-[A-Za-z0-9]+-(\d+)([A-Z]+)$", part)
                if m:
                    results.append((m.group(1), m.group(2), m.group(3)))
                    continue

                m = re.match(r"^([A-Za-z0-9]+)-(\d+)([A-Z]+)$", part)
                if m:
                    results.append((m.group(1), m.group(2), m.group(3)))
                    continue

                m = re.match(r"^(\d+)([A-Z]+)$", part)
                if m:
                    results.append((default_protein, m.group(1), m.group(2)))
                    continue

                m = re.match(r"^(\d+)([A-Z]+)\([^)]+\)$", part)
                if m:
                    results.append((default_protein, m.group(1), m.group(2)))
                    continue

                if re.match(r"^\d+$", part): continue

                print("Warning: cannot parse:", part)

            return results

        m = re.match(r"^([A-Za-z0-9]+)-[A-Za-z0-9]+-(\d+)([A-Z]+)$", residue_str)
        if m:
            results.append((m.group(1), m.group(2), m.group(3)))
            return results

        m = re.match(r"^([A-Za-z0-9]+)-(\d+)([A-Z]+)$", residue_str)
        if m:
            results.append((m.group(1), m.group(2), m.group(3)))
            return results

        m = re.match(r"^(\d+)\[([A-Z]+)\]$", residue_str)
        if m:
            for residue in m.group(2): results.append((default_protein, m.group(1), residue))
            return results

        m = re.match(r"^(\d+)([A-Z]+)$", residue_str)
        if m:
            results.append((default_protein, m.group(1), m.group(2)))
            return results

        m = re.match(r"^(\d+)([A-Z]+)\s*\([^)]+\)$", residue_str)
        if m:
            results.append((default_protein, m.group(1), m.group(2)))
            return results

        print("Warning: cannot parse residue:", residue_str)

        return results

    new_rows = []

    for _, row in dt.iterrows():

        default_protein = row["Protein Type"]

        human_parsed = parse_residues_with_protein(row["Human residues"], default_protein)
        avian_parsed = parse_residues_with_protein(row["Avian residues"], default_protein)

        if not human_parsed or not avian_parsed: continue

        human_dict, avian_dict = {}, {}

        for prot, site, aa in human_parsed: human_dict.setdefault((str(prot), int(site)), []).append(aa)
        for prot, site, aa in avian_parsed: avian_dict.setdefault((str(prot), int(site)), []).append(aa)

        for prot, site in sorted(set(human_dict) & set(avian_dict), key=lambda x: (x[0], x[1])):

            for h_res in human_dict[(prot, site)]:

                for a_res in avian_dict[(prot, site)]:

                    h_aa, a_aa = clean_aa(h_res), clean_aa(a_res)

                    if h_aa is None or a_aa is None: continue

                    new_rows.append({
                        "Protein Type": prot,
                        "Human Site": site,
                        "Human Residue": h_aa,
                        "Avian Site": site,
                        "Avian Residue": a_aa
                    })

    result_df = pd.DataFrame(new_rows).drop_duplicates(ignore_index=True)

    os.makedirs(os.path.dirname(HOST_PARSED), exist_ok=True)
    result_df.to_csv(HOST_PARSED, index=False)

    print(f"Human adaptation markers: {len(result_df)}")


# ============================================================
# Receptor preference预处理
# ============================================================

def fig1c_preprocess_recep_prefer():

    dt = pd.read_csv(RECEPTOR_RAW)
    new_rows = []

    for idx, row in dt.iterrows():

        protein = row["Protein Type"]

        for part in str(row["ori_source"]).strip().split("&"):

            part = part.strip()
            match = re.match(r"^([A-Z])(\d+)([A-Z])$", part)

            if not match:
                print(f"Skip receptor row {idx}: {part}")
                continue

            original_aa, site, target_aa = clean_aa(match.group(1)), int(match.group(2)), clean_aa(match.group(3))

            if original_aa is None or target_aa is None: continue

            new_rows.append({
                "Protein Type": protein,
                "Human Site": site,
                "Human Residue": target_aa,
                "Avian Site": site,
                "Avian Residue": original_aa
            })

    result_df = pd.DataFrame(new_rows).drop_duplicates(ignore_index=True)
    result_df.to_csv(RECEPTOR_PARSED, index=False)

    print(f"Receptor preference markers: {len(result_df)}")


# ============================================================
# Virulence预处理
# ============================================================

def fig1c_preprocess_virulence():

    dt = pd.read_csv(VIRULENCE_RAW)
    dt = dt[dt["Protein Type"] != "combination"].reset_index(drop=True)

    new_rows = []

    for idx, row in dt.iterrows():

        protein = row["Protein Type"]

        for part in str(row["ori_source"]).strip().split("&"):

            part = part.strip()
            match = re.match(r"^([A-Z])(\d+)([A-Z])$", part)

            if not match:
                print(f"Skip virulence row {idx}: {part}")
                continue

            original_aa, site, target_aa = clean_aa(match.group(1)), int(match.group(2)), clean_aa(match.group(3))

            if original_aa is None or target_aa is None: continue

            new_rows.append({
                "Protein Type": protein,
                "Human Site": site,
                "Human Residue": target_aa,
                "Avian Site": site,
                "Avian Residue": original_aa
            })

    result_df = pd.DataFrame(new_rows).drop_duplicates(ignore_index=True)
    result_df.to_csv(VIRULENCE_PARSED, index=False)

    print(f"Virulence markers: {len(result_df)}")


# ============================================================
# 合并三个marker数据集
# ============================================================

def load_combined_markers():

    dfs = []

    for filename in [HOST_PARSED, RECEPTOR_PARSED, VIRULENCE_PARSED]:

        if not os.path.exists(filename):
            warnings.warn(f"Marker file not found: {filename}")
            continue

        tmp = pd.read_csv(filename)

        required = ["Protein Type", "Human Site", "Human Residue", "Avian Residue"]

        if not all(col in tmp.columns for col in required):
            warnings.warn(f"Required columns missing in {filename}")
            continue

        dfs.append(tmp[required].copy())

    if not dfs: raise RuntimeError("No parsed marker files available.")

    dt = pd.concat(dfs, ignore_index=True)

    dt["Human Site"] = pd.to_numeric(dt["Human Site"], errors="coerce")
    dt = dt[dt["Human Site"].notna()].copy()
    dt["Human Site"] = dt["Human Site"].astype(int)

    dt["Human Residue"] = dt["Human Residue"].apply(clean_aa)
    dt["Avian Residue"] = dt["Avian Residue"].apply(clean_aa)

    dt = dt[dt["Human Residue"].notna() & dt["Avian Residue"].notna()].copy()

    n_before = len(dt)

    # 替换前后相同：整个marker删除
    dt = dt[dt["Human Residue"] != dt["Avian Residue"]].copy()

    print("\nCombined marker filtering")
    print("Before same-AA filtering:", n_before)
    print("Removed same-AA:", n_before - len(dt))

    # 三类场景合并后完全相同的mutation只保留一次
    dt = dt.drop_duplicates(
        subset=["Protein Type", "Human Site", "Avian Residue", "Human Residue"]
    ).reset_index(drop=True)

    print("Unique combined substitutions:", len(dt))

    return dt


# ============================================================
# 读取三个FASTA目录
#
# 如果同名蛋白出现在多个目录：
# 合并所有序列后再统一随机抽取1000条。
# ============================================================

def load_and_sample_all_fastas(fasta_dirs, n_sequences=1000, seed=42):

    rng = random.Random(seed)
    sequences_by_protein = {}

    for fasta_dir in fasta_dirs:

        if not os.path.isdir(fasta_dir):
            warnings.warn(f"FASTA directory not found: {fasta_dir}")
            continue

        fasta_files = sorted([
            os.path.join(fasta_dir, f)
            for f in os.listdir(fasta_dir)
            if f.endswith((".fas", ".fasta", ".fa"))
        ])

        for fasta_file in fasta_files:

            protein = os.path.splitext(os.path.basename(fasta_file))[0]

            seqs = [str(record.seq).upper() for record in SeqIO.parse(fasta_file, "fasta")]

            sequences_by_protein.setdefault(protein, []).extend(seqs)

    sampled_by_protein = {}

    for protein, sequences in sequences_by_protein.items():

        # 完全重复序列去重可以显著降低内存，也避免重复FASTA文件造成重复加权
        sequences = list(dict.fromkeys(sequences))

        if len(sequences) == 0: continue

        sampled = rng.sample(sequences, n_sequences) if len(sequences) >= n_sequences else sequences.copy()

        sampled_by_protein[protein] = sampled

        print(f"{protein}: available unique={len(sequences)}, sampled={len(sampled)}")

    return sampled_by_protein


# ============================================================
# FASTA → NumPy矩阵
#
# shape:
#     n_sequences × max_length
#
# 非有效位置填 "-"
# ============================================================

def sequences_to_matrix(sequences):

    if len(sequences) == 0: return np.empty((0, 0), dtype="U1")

    max_len = max(map(len, sequences))

    matrix = np.full((len(sequences), max_len), "-", dtype="U1")

    for i, seq in enumerate(sequences):
        chars = np.fromiter(seq, dtype="U1", count=len(seq))
        matrix[i, :len(chars)] = chars

    return matrix


# ============================================================
# 一次性建立蛋白矩阵
# ============================================================

def build_sequence_matrices(sampled_sequences):

    matrices = {}

    for protein, sequences in sampled_sequences.items():
        matrices[protein] = sequences_to_matrix(sequences)
        print(f"{protein}: matrix = {matrices[protein].shape}")

    return matrices


# ============================================================
# 某个位点的AA counts
#
# 使用NumPy，不再逐序列循环
# ============================================================

def get_site_counts(matrix, site):

    if matrix.size == 0 or site < 1 or site > matrix.shape[1]: return {}, 0

    column = matrix[:, site - 1]

    valid_mask = np.isin(column, VALID_AA)
    column = column[valid_mask]

    if len(column) == 0: return {}, 0

    aa, counts = np.unique(column, return_counts=True)

    return dict(zip(aa.tolist(), counts.tolist())), len(column)


# ============================================================
# 根据counts计算conservation
# ============================================================

def conservation_from_counts(count_dict):

    if not count_dict: return np.nan, np.nan, np.nan

    counts = np.asarray(list(count_dict.values()), dtype=float)
    p = counts / counts.sum()

    entropy = -np.sum(p * np.log2(p))
    information_content = np.log2(N_AA) - entropy
    conservation = 1.0 - entropy / np.log2(N_AA)

    return entropy, information_content, conservation


# ============================================================
# 根据counts计算目标AA frequency / rarity
# ============================================================

def frequency_from_counts(count_dict, target_aa, pseudocount=PSEUDOCOUNT):

    total = sum(count_dict.values())

    if total == 0: return np.nan

    count = count_dict.get(target_aa, 0)

    return (count + pseudocount) / (total + N_AA * pseudocount)


def rarity_from_counts(count_dict, target_aa):

    freq = frequency_from_counts(count_dict, target_aa)

    return -np.log10(freq) if not np.isnan(freq) and freq > 0 else np.nan


# ============================================================
# Combined分析
# ============================================================

def analyse_combined_conservation_rarity():

    markers = load_combined_markers()

    sampled_sequences = load_and_sample_all_fastas(
        fasta_dirs=FASTA_DIRS,
        n_sequences=N_SEQUENCES,
        seed=RANDOM_SEED
    )

    sequence_matrices = build_sequence_matrices(sampled_sequences)

    # --------------------------------------------------------
    # 只缓存真正用到的marker sites
    #
    # key:
    #   (protein, site)
    #
    # value:
    #   counts / N / entropy / conservation
    # --------------------------------------------------------

    site_cache = {}

    unique_sites = markers[["Protein Type", "Human Site"]].drop_duplicates()

    print("\nPre-calculating marker-site distributions...")

    for _, row in unique_sites.iterrows():

        protein = str(row["Protein Type"])
        site = int(row["Human Site"])

        if protein not in sequence_matrices:
            print(f"Warning: no sequence matrix for {protein}")
            continue

        matrix = sequence_matrices[protein]

        counts, n_valid = get_site_counts(matrix, site)

        if matrix.shape[0] == 0: continue

        valid_fraction = n_valid / matrix.shape[0]

        if valid_fraction < MIN_VALID_FRACTION:
            print(f"Skip {protein}:{site}; valid fraction={valid_fraction:.3f}")
            continue

        entropy, information_content, conservation = conservation_from_counts(counts)

        site_cache[(protein, site)] = {
            "counts": counts,
            "N valid": n_valid,
            "Valid fraction": valid_fraction,
            "Entropy": entropy,
            "Information content": information_content,
            "Conservation": conservation
        }

    print("Cached marker sites:", len(site_cache))

    # ========================================================
    # Marker analysis
    # ========================================================

    summary_rows = []
    long_rows = []

    for marker_id, row in markers.iterrows():

        protein = str(row["Protein Type"])
        site = int(row["Human Site"])
        original_aa = row["Avian Residue"]
        substitution_aa = row["Human Residue"]

        key = (protein, site)

        if key not in site_cache: continue

        site_data = site_cache[key]
        counts = site_data["counts"]

        # ----------------------------------------------------
        # Substitution rarity
        # ----------------------------------------------------

        substitution_count = counts.get(substitution_aa, 0)
        substitution_frequency = frequency_from_counts(counts, substitution_aa)
        substitution_rarity = rarity_from_counts(counts, substitution_aa)

        original_count = counts.get(original_aa, 0)
        original_frequency = frequency_from_counts(counts, original_aa)

        # ----------------------------------------------------
        # Control
        #
        # 去掉original AA
        # 保留AA真实频率
        #
        # 不需要真的创建数百个字符串，
        # 直接使用 count 作为权重计算，速度更快。
        # ----------------------------------------------------

        control_counts = {aa: count for aa, count in counts.items() if aa != original_aa and count > 0}

        n_control = sum(control_counts.values())

        if n_control == 0:
            print(f"Skip {protein}:{site} {original_aa}->{substitution_aa}; no control residues")
            continue

        control_aa_rarity = {aa: rarity_from_counts(counts, aa) for aa in control_counts}

        # 加权mean：等价于把AA按真实出现次数展开后取平均
        control_rarity_mean = sum(control_aa_rarity[aa] * count for aa, count in control_counts.items()) / n_control

        # 加权数据用于median/percentile
        expanded_control_rarity = np.concatenate([
            np.repeat(control_aa_rarity[aa], count)
            for aa, count in control_counts.items()
        ])

        control_rarity_median = np.median(expanded_control_rarity)

        # 替换AA比多少比例的control更加rare
        rarity_percentile = np.mean(expanded_control_rarity <= substitution_rarity)

        site_frequency_string = ";".join(
            f"{aa}:{count}"
            for aa, count in sorted(counts.items())
        )

        summary_rows.append({
            "Marker ID": marker_id,
            "Protein Type": protein,
            "Site": site,
            "Original Residue": original_aa,
            "Substitution Residue": substitution_aa,
            "N valid site residues": site_data["N valid"],
            "Valid fraction": site_data["Valid fraction"],
            "Site residue frequency": site_frequency_string,
            "Entropy": site_data["Entropy"],
            "Information content": site_data["Information content"],
            "Conservation": site_data["Conservation"],
            "Original count": original_count,
            "Original frequency": original_frequency,
            "Substitution count": substitution_count,
            "Substitution frequency": substitution_frequency,
            "Substitution rarity": substitution_rarity,
            "N control residues": n_control,
            "Control rarity mean": control_rarity_mean,
            "Control rarity median": control_rarity_median,
            "Substitution-Control rarity difference": substitution_rarity - control_rarity_mean,
            "Substitution rarity percentile": rarity_percentile
        })

        long_rows.append({
            "Marker ID": marker_id,
            "Protein Type": protein,
            "Site": site,
            "Original Residue": original_aa,
            "Target Residue": substitution_aa,
            "Group": "Substitution",
            "Rarity": substitution_rarity
        })

        # long-format也按频率保留
        for aa, count in control_counts.items():

            rarity = control_aa_rarity[aa]

            for _ in range(count):
                long_rows.append({
                    "Marker ID": marker_id,
                    "Protein Type": protein,
                    "Site": site,
                    "Original Residue": original_aa,
                    "Target Residue": aa,
                    "Group": "Control",
                    "Rarity": rarity
                })

    summary_df = pd.DataFrame(summary_rows)
    long_df = pd.DataFrame(long_rows)

    summary_df.to_csv(f"{OUTPUT_PREFIX}_site_summary.csv", index=False)
    long_df.to_csv(f"{OUTPUT_PREFIX}_rarity_long.csv", index=False)

    print("\n" + "=" * 70)
    print("Combined analysis completed")
    print("Combined substitutions retained:", len(summary_df))
    print("=" * 70)

    return summary_df, long_df


# ============================================================
# Combined Substitution vs Control统计
# ============================================================

def calculate_combined_statistics(summary_df):

    tmp = summary_df[["Substitution rarity", "Control rarity mean"]].dropna().copy()

    if len(tmp) < 2: raise RuntimeError("Not enough paired observations for statistical analysis.")

    substitution = tmp["Substitution rarity"].to_numpy()
    control = tmp["Control rarity mean"].to_numpy()
    paired_difference = substitution - control

    if np.allclose(paired_difference, 0):
        statistic, p_value = 0.0, 1.0
    else:
        statistic, p_value = wilcoxon(
            substitution,
            control,
            alternative="two-sided",
            zero_method="wilcox"
        )

    stats_df = pd.DataFrame([{
        "N": len(tmp),
        "Substitution mean": np.mean(substitution),
        "Control mean": np.mean(control),
        "Substitution median": np.median(substitution),
        "Control median": np.median(control),
        "Mean paired difference": np.mean(paired_difference),
        "Median paired difference": np.median(paired_difference),
        "Wilcoxon statistic": statistic,
        "P value": p_value,
        "Significance": significance_label(p_value)
    }])

    stats_df.to_csv(f"{OUTPUT_PREFIX}_statistics.csv", index=False)

    print("\nCombined rarity statistics:")
    print(stats_df.round(6).to_string(index=False))

    return stats_df


# ============================================================
# Combined箱线图
# ============================================================

def plot_combined_rarity(summary_df, stats_df):

    tmp = summary_df[["Substitution rarity", "Control rarity mean"]].dropna().copy()

    substitution = tmp["Substitution rarity"].to_numpy()
    control = tmp["Control rarity mean"].to_numpy()

    p_value = stats_df.iloc[0]["P value"]
    sig = stats_df.iloc[0]["Significance"]

    fig, ax = plt.subplots(figsize=(3, 3))

    # --------------------------------------------------------
    # Boxplot
    # --------------------------------------------------------

    ax.boxplot(
        [substitution, control],
        positions=[1, 2],
        widths=0.52,
        showfliers=False,
        patch_artist=True,
        boxprops={"facecolor": "white", "edgecolor": "black", "linewidth": 1.2},
        medianprops={"color": "black", "linewidth": 1.5},
        whiskerprops={"color": "black", "linewidth": 1.0},
        capprops={"color": "black", "linewidth": 1.0}
    )

    # --------------------------------------------------------
    # Scatter
    # 不添加paired connecting lines
    # --------------------------------------------------------

    rng = np.random.default_rng(RANDOM_SEED)

    ax.scatter(rng.normal(1, 0.045, len(substitution)), substitution, s=20, alpha=0.55, zorder=3)
    ax.scatter(rng.normal(2, 0.045, len(control)), control, s=20, alpha=0.55, zorder=3)

    # --------------------------------------------------------
    # Significance bracket
    # --------------------------------------------------------

    all_values = np.concatenate([substitution, control])

    data_min = np.nanmin(all_values)
    data_max = np.nanmax(all_values)
    data_range = data_max - data_min

    if data_range == 0: data_range = max(abs(data_max), 1.0)

    line_y = data_max + 0.10 * data_range
    bracket_height = 0.035 * data_range
    text_y = line_y + bracket_height + 0.015 * data_range

    ax.plot(
        [1, 1, 2, 2],
        [line_y, line_y + bracket_height, line_y + bracket_height, line_y],
        color="black",
        linewidth=1
    )

    ax.text(1.5, text_y, sig, ha="center", va="bottom", fontsize=12)

    # --------------------------------------------------------
    # Axis
    # --------------------------------------------------------

    ax.set_ylim(max(0, data_min - 0.08 * data_range), text_y + 0.12 * data_range)

    ax.set_xticks([1, 2])
    ax.set_xticklabels(["Substitution", "Control"], fontsize=10)

    ax.set_ylabel(r"Rarity score", fontsize=12)
    ax.set_xlabel("")

    ax.tick_params(axis="y", labelsize=10)

    ax.spines["top"].set_linewidth(1.2)
    ax.spines["right"].set_linewidth(1.2)
    ax.spines["bottom"].set_linewidth(1.2)
    ax.spines["left"].set_linewidth(1.2)

    # 显示精确P值
    #ax.text(
    #    0.98,
    #    0.98,
    #    f"Wilcoxon P = {p_value:.3g}",
    #    transform=ax.transAxes,
    #    ha="right",
    #    va="top",
    #    fontsize=8
    #)

    fig.tight_layout()

    os.makedirs(os.path.dirname(FIGURE_FILE), exist_ok=True)

    # 只输出PDF
    fig.savefig(FIGURE_FILE, dpi=300, bbox_inches="tight")

    plt.close(fig)

    print("PDF saved:", FIGURE_FILE)


# ============================================================
# Conservation描述性汇总
#
# 注意：
# conservation是position属性，
# Substitution和Control在同一位置时完全相同，
# 因此不做Substitution vs Control检验。
# ============================================================

def summarize_conservation(summary_df):

    conservation_df = summary_df[
        [
            "Protein Type",
            "Site",
            "Conservation",
            "Entropy",
            "Information content"
        ]
    ].drop_duplicates(
        subset=["Protein Type", "Site"]
    )

    conservation_df.to_csv(
        f"{OUTPUT_PREFIX}_marker_site_conservation.csv",
        index=False
    )

    summary = pd.DataFrame([{
        "N marker sites": len(conservation_df),
        "Mean conservation": conservation_df["Conservation"].mean(),
        "Median conservation": conservation_df["Conservation"].median(),
        "Mean entropy": conservation_df["Entropy"].mean(),
        "Median entropy": conservation_df["Entropy"].median()
    }])

    summary.to_csv(
        f"{OUTPUT_PREFIX}_conservation_summary.csv",
        index=False
    )

    print("\nMarker-site conservation:")
    print(summary.round(4).to_string(index=False))

    return conservation_df, summary


# ============================================================
# Main
# ============================================================

if __name__ == "__main__":

    # --------------------------------------------------------
    # 如果预处理文件已经存在、且原始marker没有变化，
    # 可以把下面三行注释掉，进一步节省运行时间。
    # --------------------------------------------------------

    fig1c_preprocess_host_adaptation()
    fig1c_preprocess_recep_prefer()
    fig1c_preprocess_virulence()

    # --------------------------------------------------------
    # 三类marker合并后统一分析
    # --------------------------------------------------------

    summary_df, long_df = analyse_combined_conservation_rarity()

    # Substitution vs Control
    stats_df = calculate_combined_statistics(summary_df)

    # 只生成一个PDF
    plot_combined_rarity(summary_df, stats_df)

    # conservation作为marker位点属性单独保存
    conservation_df, conservation_summary = summarize_conservation(summary_df)