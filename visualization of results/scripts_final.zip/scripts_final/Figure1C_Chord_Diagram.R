# ============================================================
# Fig1C Amino-acid substitution chord diagram
#
# 修改：
# 1. 去掉替换方向：A->B 与 B->A 合并为 A--B
# 2. 删除 A->A 等自身替换
# 3. 按无方向替换总次数统计，Top 10 高亮
#
# Track 1 = Polarity
# Track 2 = Hydropathy
# Track 3 = AA labels
# Track 4 = Charge
# ============================================================

# ============================================================
# 0. 加载R包
# ============================================================
library(circlize)
library(RColorBrewer)
library(dplyr)
library(tidyr)

setwd("/Users/zhiyuanzhang/Documents/XiangZefeng/dataset_and_figures/scripts")

# ============================================================
# 1. 读取数据
# ============================================================
dt_adapt <- read.csv("../dataset_zzy/dt_for_fig1c_human_adaptation.csv", sep = "\t", header = TRUE)
dt_recep <- read.csv("../dataset_zzy/dt_for_fig1c_recep_prefer.csv", sep = "\t", header = TRUE)
dt_vir <- read.csv("../dataset_zzy/dt_for_fig1c_virulence.csv", sep = "\t", header = TRUE)

# ============================================================
# 2. 只保留需要的列并合并
# ============================================================
dt_adapt <- dt_adapt[, c("Protein.Type", "Human.Residue", "Avian.Residue")]
dt_recep <- dt_recep[, c("Protein.Type", "Human.Residue", "Avian.Residue")]
dt_vir <- dt_vir[, c("Protein.Type", "Human.Residue", "Avian.Residue")]
dt <- rbind(dt_adapt, dt_recep, dt_vir)

# ============================================================
# 3. Protein Type → influenza segment
# ============================================================
segment_mapping <- c("PB2" = "PB2", "PB1" = "PB1", "PB1-F2" = "PB1", "PA" = "PA", "PA-X" = "PA", "NP" = "NP", "H1" = "HA", "H2" = "HA", "H3" = "HA", "H3-HA1" = "HA", "H3-HA2" = "HA", "H5" = "HA", "H7" = "HA", "H9" = "HA", "H9-HA1" = "HA", "H10" = "HA", "H13" = "HA", "H16" = "HA", "H18" = "HA", "HA1" = "HA", "HA2" = "HA", "N1" = "NA", "N2" = "NA", "N7" = "NA", "N8" = "NA", "NEP" = "NA", "M" = "M", "M1" = "M", "M2" = "M", "NS1" = "NS", "NS2" = "NS")

dt$Segment <- segment_mapping[dt$Protein.Type]
dt <- dt[!is.na(dt$Segment), ]

# ============================================================
# 4. 20种标准氨基酸
# ============================================================
all_amino_acids <- c("A", "C", "D", "E", "F", "G", "H", "I", "K", "L", "M", "N", "P", "Q", "R", "S", "T", "V", "W", "Y")

# ============================================================
# 5. Charge
# ============================================================
charge_groups <- list(Acidic = c("D", "E"), Basic = c("K", "R", "H"), Neutral = c("A", "N", "C", "Q", "G", "I", "L", "M", "F", "P", "S", "T", "V", "W", "Y"))
charge_colors <- c("Acidic" = "#DC143C", "Basic" = "#1E90FF", "Neutral" = "#32CD32")

# ============================================================
# 6. Hydropathy
# ============================================================
hydropathy_groups <- list(Hydrophobic = c("A", "I", "L", "M", "F", "V", "P", "W"), Hydrophilic = c("R", "N", "D", "E", "Q", "K", "S", "T", "Y", "G", "C", "H"))
hydropathy_colors <- c("Hydrophobic" = "#F98B30", "Hydrophilic" = "#39FEF1")

# ============================================================
# 7. Polarity
# ============================================================
polarity_groups <- list(Polar = c("R", "N", "D", "E", "Q", "K", "S", "T", "Y", "C", "H"), Nonpolar = c("A", "F", "G", "I", "L", "M", "P", "V", "W"))
polarity_colors <- c("Polar" = "#A640F8", "Nonpolar" = "#2F4F4F")

# ============================================================
# 8. AA属性表
# ============================================================
aa_properties <- data.frame(
  AA = all_amino_acids,
  Charge = sapply(all_amino_acids, function(aa) { for (g in names(charge_groups)) if (aa %in% charge_groups[[g]]) return(g); return(NA) }),
  Hydropathy = sapply(all_amino_acids, function(aa) { for (g in names(hydropathy_groups)) if (aa %in% hydropathy_groups[[g]]) return(g); return(NA) }),
  Polarity = sapply(all_amino_acids, function(aa) { for (g in names(polarity_groups)) if (aa %in% polarity_groups[[g]]) return(g); return(NA) }),
  stringsAsFactors = FALSE
)

# ============================================================
# 9. 无方向替换统计
#
# A->V 与 V->A 都转换为同一个 pair
# pmin / pmax 用来固定两个AA的顺序
# 同时删除 A->A 等自身替换
# ============================================================
mutation_counts <- dt %>%
  filter(Avian.Residue %in% all_amino_acids, Human.Residue %in% all_amino_acids, Avian.Residue != Human.Residue) %>%
  mutate(from = pmin(Avian.Residue, Human.Residue), to = pmax(Avian.Residue, Human.Residue)) %>%
  group_by(from, to) %>%
  summarise(value = n(), .groups = "drop") %>%
  arrange(desc(value), from, to)

cat("\nAll undirected substitutions:\n")
print(mutation_counts)

# ============================================================
# 10. Top 10 substitution
# ============================================================
mutation_counts$IsTop <- FALSE
if (nrow(mutation_counts) > 0) mutation_counts$IsTop[1:min(10, nrow(mutation_counts))] <- TRUE

cat("\nTop 10 undirected substitutions:\n")
print(mutation_counts %>% filter(IsTop))

# ============================================================
# 11. 氨基酸排序
# ============================================================
sort_priority <- aa_properties %>%
  mutate(Charge_rank = case_when(Charge == "Acidic" ~ 1, Charge == "Basic" ~ 2, Charge == "Neutral" ~ 3, TRUE ~ 4),
         Hydropathy_rank = case_when(Hydropathy == "Hydrophilic" ~ 1, Hydropathy == "Hydrophobic" ~ 2, TRUE ~ 3)) %>%
  arrange(Charge_rank, Hydropathy_rank, AA)

aa_order <- sort_priority$AA

# 只保留实际出现的AA
used_aa <- unique(c(mutation_counts$from, mutation_counts$to))
aa_order_used <- aa_order[aa_order %in% used_aa]

# ============================================================
# 12. Charge颜色
# ============================================================
grid_colors <- setNames(sapply(aa_order_used, function(aa) { charge_type <- aa_properties$Charge[aa_properties$AA == aa]; charge_colors[charge_type] }), aa_order_used)

# ============================================================
# 13. 弦颜色
# ============================================================
link_col <- ifelse(mutation_counts$IsTop, "#FFD000CC", "#80808020")
link_lwd <- ifelse(mutation_counts$IsTop, 1.5, 0.3)

# ============================================================
# 14. 创建PDF
# ============================================================
pdf("../figures/fig1c_combined_chord.pdf", width = 11, height = 10, useDingbats = FALSE)

# ============================================================
# 15. 初始化circos
# ============================================================
circos.clear()
circos.par(start.degree = 90, gap.degree = 3, track.margin = c(0.002, 0.002), cell.padding = c(0, 0, 0, 0), points.overflow.warning = FALSE)
par(mar = c(1, 1, 1, 7))

# ============================================================
# 16. 无方向弦图
#
# directional = 0
# 不再绘制箭头
# ============================================================
chordDiagram(
  x = mutation_counts[, c("from", "to", "value")],
  grid.col = grid_colors,
  order = aa_order_used,
  directional = 0,
  annotationTrack = "grid",
  annotationTrackHeight = 0.055,
  preAllocateTracks = list(list(track.height = 0.055), list(track.height = 0.055), list(track.height = 0.060)),
  link.sort = TRUE,
  link.largest.ontop = TRUE,
  col = link_col,
  link.lwd = link_lwd
)

# ============================================================
# 17. Track 3: Amino-acid labels
# ============================================================
circos.trackPlotRegion(track.index = 3, bg.border = NA, bg.col = NA, panel.fun = function(x, y) {
  sector.index <- get.cell.meta.data("sector.index"); xlim <- get.cell.meta.data("xlim")
  circos.text(mean(xlim), 0.5, labels = sector.index, facing = "bending.inside", niceFacing = TRUE, cex = 1.15, font = 2, col = "black")
})

# ============================================================
# 18. Track 2: Hydropathy
# ============================================================
circos.trackPlotRegion(track.index = 2, bg.border = NA, panel.fun = function(x, y) {
  sector.index <- get.cell.meta.data("sector.index"); xlim <- get.cell.meta.data("xlim")
  hydro_type <- aa_properties$Hydropathy[aa_properties$AA == sector.index]; this_color <- hydropathy_colors[hydro_type]
  if (length(this_color) > 0 && !is.na(this_color)) circos.rect(xlim[1], 0, xlim[2], 1, col = this_color, border = "white", lwd = 0.7)
})

# ============================================================
# 19. Track 1: Polarity
# ============================================================
circos.trackPlotRegion(track.index = 1, bg.border = NA, panel.fun = function(x, y) {
  sector.index <- get.cell.meta.data("sector.index"); xlim <- get.cell.meta.data("xlim")
  polarity_type <- aa_properties$Polarity[aa_properties$AA == sector.index]; this_color <- polarity_colors[polarity_type]
  if (length(this_color) > 0 && !is.na(this_color)) circos.rect(xlim[1], 0, xlim[2], 1, col = this_color, border = "white", lwd = 0.7)
})

# ============================================================
# 20. 图例
# ============================================================
par(xpd = TRUE)

legend(x = 1.12, y = 0.96, legend = names(charge_colors), fill = charge_colors, border = NA, title = "Charge", cex = 1.2, bty = "n")
legend(x = 1.12, y = 0.78, legend = names(hydropathy_colors), fill = hydropathy_colors, border = NA, title = "Hydropathy", cex = 1.2, bty = "n")
legend(x = 1.12, y = 0.59, legend = names(polarity_colors), fill = polarity_colors, border = NA, title = "Polarity", cex = 1.2, bty = "n")
#legend(x = 1.12, y = 0.40, legend = c("Top 10 substitutions", "Other substitutions"), col = c("#FFD000CC", "#80808050"), lwd = c(4, 1), title = "Substitution", cex = 0.8, bty = "n")

# ============================================================
# 21. 完成
# ============================================================
circos.clear()
dev.off()

# ============================================================
# 22. 输出Top 10
# ============================================================
top10_substitutions <- mutation_counts %>% head(10) %>% select(from, to, value)
print(top10_substitutions)
write.csv(top10_substitutions, "../dataset_zzy/fig1c_top10_undirected_substitutions.csv", row.names = FALSE)