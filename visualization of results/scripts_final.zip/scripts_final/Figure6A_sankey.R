library(ggsankey)
library(ggplot2)
library(dplyr)
library(readr)

setwd("/Users/zhiyuanzhang/Documents/XiangZefeng/dataset_and_figures/scripts/")

# ---- 1. 读取数据 ----
dt <- read_csv("../dataset_xzf/application_on_H5N1/final_merged_pred_with_resistance_matched.csv",
               show_col_types = FALSE)

dt <- dt %>%
  select(Strain.ID = `Strain ID`,
         vir_pred_label_mean,
         rece_pred_label_mean,
         host_pred_name_mean)

# ---- 2. 构造三个分类列（与 Python 端一致）----
dt <- dt %>%
  mutate(
    Host = case_when(
      host_pred_name_mean == "Avian" ~ "Avian host",
      TRUE                           ~ "Non-avian host"
    ),
    Virulence = case_when(
      vir_pred_label_mean == 1 ~ "High virulence",
      vir_pred_label_mean == 0 ~ "Low virulence",
      TRUE                     ~ NA_character_
    ),
    Receptor = case_when(
      rece_pred_label_mean == 0 ~ "Human-binding",
      rece_pred_label_mean == 1 ~ "Avian-binding",
      TRUE                      ~ NA_character_
    )
  ) %>%
  filter(!is.na(Virulence), !is.na(Receptor), !is.na(Host))


# ---- 3. 转成 long 格式 ----
# 顺序与 Python 端 layers 一致：Host -> Virulence -> Receptor
df_long <- dt %>%
  make_long(Host, Virulence, Receptor)


node_colors <- c(
  "Avian host"       = "#1f77b4",   # 蓝色
  "Non-avian host"   = "#aec7e8",   # 浅蓝（同类延展，避免灰色）
  "Low virulence"    = "#2ca02c",   # 绿色
  "High virulence"   = "#d62728",   # 红色
  "Human-binding"    = "#9467bd",   # 紫色
  "Avian-binding"    = "#ff7f0e"    # 橙色
)

# ---- 4. 绘图 ----
p <- ggplot(
  df_long,
  aes(x = x,
      next_x = next_x,
      node = node,
      next_node = next_node,
      fill = factor(node),
      label = node)
) +
  geom_sankey(flow.alpha = 0.5, node.color = 1) +
  geom_sankey_label(size = 3.2, color = 1, fill = "white") +
  scale_fill_manual(values = node_colors, drop = FALSE) +
  theme_sankey(base_size = 12) +
  theme(
    legend.position = "none",
    axis.title.x = element_blank(),
    axis.text.x = element_text(size = 12, color = "black"),
    plot.margin = margin(5, 5, 5, 5)
  )


# ---- 5. 保存 PDF ----
ggsave(
  filename = "../figures/Figure_6_sankey.pdf",
  plot = p,
  width = 9,
  height = 4.5,
  units = "in",
  device = cairo_pdf
)













library(ggsankey)
library(ggplot2)
library(dplyr)
library(readr)
library(readxl)
library(tidyverse)
library(ggalluvial)


setwd("/Users/zhiyuanzhang/Documents/XiangZefeng/dataset_and_figures/scripts/")

# ---- 1. 读取数据 ----
dt <- read_excel("../dataset_xzf/application_on_H5N1/H5_final_merged_pred.xlsx")

dt <- dt %>%
  select(Strain.ID = `Strain ID`,
         Genotype,
         vir_pred_label_mean,
         rece_pred_label_mean,
         host_pred_name_mean)

# ---- 2. 构造分类列 ----
dt <- dt %>%
  mutate(
    Host = case_when(
      host_pred_name_mean == "Avian" ~ "Avian host",
      host_pred_name_mean == "Swine" ~ "Swine host",
      host_pred_name_mean == "Human" ~ "Human host",
      TRUE                           ~ NA_character_
    ),
    Virulence = case_when(
      vir_pred_label_mean == 1 ~ "High virulence",
      vir_pred_label_mean == 0 ~ "Low virulence",
      TRUE                     ~ NA_character_
    ),
    Receptor = case_when(
      rece_pred_label_mean == 0 ~ "Avian receptor",
      rece_pred_label_mean == 1 ~ "Human receptor",
      TRUE                      ~ NA_character_
    )
  ) %>%
  filter(!is.na(Genotype),
         !is.na(Virulence),
         !is.na(Receptor),
         !is.na(Host))

# ---- 3. 转 long：Genotype → Virulence → Receptor → Host ----
df_long <- dt %>%
  make_long(Genotype, Virulence, Receptor, Host)

# ---- 4. 节点计数 ----
node_counts <- df_long %>%
  count(x, node, name = "n")

df_long <- df_long %>%
  left_join(node_counts, by = c("x", "node")) %>%
  mutate(node_label = paste0(node, "\n(n=", n, ")"))

if (any(is.na(df_long$n))) {
  warning("有节点的计数为 NA，请检查 node_counts 的 join 键。")
}

# ---- 5. 颜色 ----
node_colors <- c(
  "Avian host"       = "#1f77b4",
  "Swine host"       = "#aec7e8",
  "Human host"       = "#d62100",
  "Low virulence"    = "#2ca02c",
  "High virulence"   = "#FF0000",
  "Human receptor"   = "#9467bd",
  "Avian receptor"   = "#ff7f0e"
)

geno_levels <- sort(unique(dt$Genotype))
geno_colors <- setNames(
  grDevices::hcl.colors(length(geno_levels), "Dark 3"),
  geno_levels
)

all_colors <- c(geno_colors, node_colors)

# ---- 6. 绘图 ----
p <- ggplot(
  df_long,
  aes(x = x,
      next_x = next_x,
      node = node,
      next_node = next_node,
      fill = factor(node),
      label = node_label)
) +
  geom_sankey(flow.alpha = 0.5, node.color = 1) +
  geom_sankey_label(size = 2.9, color = 1, fill = "white") +
  scale_fill_manual(values = all_colors, drop = FALSE) +
  scale_x_discrete(
    labels = c(
      Genotype  = "Genotype",
      Virulence = "Virulence",
      Receptor  = "Receptor-binding",
      Host      = "Host"
    )
  ) +
  theme_sankey(base_size = 14) +
  theme(
    legend.position = "none",
    axis.title.x = element_blank(),
    axis.text.x = element_text(size = 14, color = "black"),
    plot.margin = margin(5, 5, 5, 5)
  )

# ---- 7. 保存 ----
dir.create("../figures", showWarnings = FALSE, recursive = TRUE)
ggsave(
  filename = "../figures/Figure_6_sankey.pdf",
  plot = p,
  width = 10,
  height = 4.5,
  units = "in",
  device = cairo_pdf
)